<footer class="main-footer">
    <strong>&copy; TeensYouths <?php echo date("Y"); ?></strong>
    <div class="float-right d-none d-sm-inline-block">
      <b>Developed by</b> <a target="_blank" href="https://doteightplus.com">DotEightPlus</a>
    </div>
  </footer>
